package interfaces;

public interface Id {
}
