import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Proj3_02 {
    static final Lock[] locks=new Lock[5];
    static {
        for (int i=0;i<locks.length;i++){
            locks[i]=new ReentrantLock();
        }
    }
 
    public static void main(String[] args) {
        Philosopher philosopher0=new Philosopher("张三",1000,0);
        Philosopher philosopher1=new Philosopher("李四",800,1);
        Philosopher philosopher2=new Philosopher("王五",400,2);
        Philosopher philosopher3=new Philosopher("jhl",2000,3);
        Philosopher philosopher4=new Philosopher("ghlcl",2000,4);
        philosopher0.start();
        philosopher1.start();
        philosopher2.start();
        philosopher3.start();
        philosopher4.start();
        //死循环，防止主线程退出导致进程关闭
        while (true){}
    }
 
    static class Philosopher extends Thread{
        private String name;
        private long time;
        private int num;
 
        public Philosopher(String name, long time, int num) {
            this.name = name;
            this.time = time;
            this.num = num;
        }
 
        @Override
        public void run() {
            while (true){
                System.out.println(num+"号哲学家"+name+"正在思考...");
                //模拟思考的过程
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(num+"号哲学家"+name+"饿了，想来吃饭...");
                if (locks[num].tryLock()){
                    try {
                        System.out.println(num+"号哲学家"+name+"拿到了左边的筷子！");
                        if (locks[(num+1)%5].tryLock()){
                            try {
                                System.out.println(num+"号哲学家"+name+"拿到了右边的筷子！");
                                System.out.println(num+"号哲学家"+name+"开始吃饭！");
                                //模拟哲学家吃饭的过程
                                Thread.sleep(time);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            } finally {
                                System.out.println(num+"号哲学家"+name+"放下了右边的筷子！");
                                locks[(num+1)%5].unlock();
                            }
                        }else {
                            System.out.println(num+"号哲学家"+name+"没拿到了右边的筷子！被迫思考...");
                        }
                    }finally {
                        System.out.println(num+"号哲学家"+name+"放下了左边的筷子！");
                        locks[num].unlock();
                    }
                }else {
                    System.out.println(num+"号哲学家"+name+"没拿到了左边的筷子！被迫思考...");
                }
                System.out.println(num+"号哲学家"+name+"思考ing...");
                //模拟思考过程
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}